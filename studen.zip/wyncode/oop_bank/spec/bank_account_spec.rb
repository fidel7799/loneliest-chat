# spec/bank_account_spec.rb
describe BankAccount do

end
