class TeamsController < ApplicationController
  def league
  end

  def eastern_conf
  end

  def western_conf
  end
end
