# Google Like a Developer
Tips and tricks to find solutions through googling

![Infographic](http://d2ykiwzv4lwge4.cloudfront.net/wp-content/uploads/2015/03/Wyncode-Google-infographic-01.jpg)
