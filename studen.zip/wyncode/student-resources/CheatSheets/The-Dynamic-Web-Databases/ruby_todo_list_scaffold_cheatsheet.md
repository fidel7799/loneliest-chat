```bash
rails new todo
```

```bash
cd todo
```

```bash
rails g scaffold todo_item description:string --javascript-engine=js --stylesheet-engine=css
```

```bash
rake db:migrate
```

```bash
rake routes
```

```bash
rails server
```

```bash
 ls app/views/todo_items/
 ```

```bash
ls app/assets/javascripts/
```

```bash
ls app/assets/stylesheets/
```
