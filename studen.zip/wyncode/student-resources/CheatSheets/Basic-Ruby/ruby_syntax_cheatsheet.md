Code snippets Ruby Syntax 0.3.0

```ruby
irb
http://repl.it/languages/Ruby
```

```ruby
print "Hello world!"
```

```ruby
1+1
1-1
2*2
4/2
```

```ruby
1/3
5/2
```

```ruby
1-1.0/3
```

```ruby
print "Hello world!"
Kernel.print("Hello world!")
```

```ruby
1.+(1).*(2)
2.*(2)
```
