Code snippets Ruby Programs

```ruby
cd ~/Desktop/
ruby hello.rb
```

```ruby
"Hello world!"
"Hello world!"
"Hello world!"
"Hello world!"

Terminal
 ruby hello.rb
```

```ruby
puts "Hello world!"
p "Hello world!"
p "Hello world!\n"
puts RUBY_VERSION
p RUBY_VERSION

```

```ruby
1.+()
puts "Hello world!"
puts RUBY_VERSION
```
