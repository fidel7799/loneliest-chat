class Review < ActiveRecord::Base
  belongs_to :babysitter
end
