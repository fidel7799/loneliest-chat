class StaticController < ApplicationController
  def welcome
  end
end
