require 'test_helper'

class BabysitterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
