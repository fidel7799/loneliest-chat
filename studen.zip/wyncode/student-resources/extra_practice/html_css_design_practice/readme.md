## Recommended Links

- [Code School](https://www.codeschool.com/paths/html-css)
- [Codecademy](https://www.codecademy.com/learn/web)
- [Code Avengers](https://www.codeavengers.com/profile#html-css)

### Practice
- [Codepen](http://codepen.io/)
