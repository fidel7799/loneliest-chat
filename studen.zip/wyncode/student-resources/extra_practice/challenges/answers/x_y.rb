y = 9
if y = 10
  x = 0
else
  x = 1
end
