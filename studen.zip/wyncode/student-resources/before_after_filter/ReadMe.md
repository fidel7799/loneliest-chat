#Before and After Filters

##Instructions
1. Create your own Gist with a refactored version of the users controller titles `filter.rb` using filters(`before_action`, and `after_action`)
3. Submit the Gist of your refactored code in the prompt on Goodmeasure week 5
4. Good Luck!
