# sinatra

for this project i used sinatra and html as a marckup language

download it and enjoy it :)
