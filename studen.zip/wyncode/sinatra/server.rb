require 'sinatra'
require 'nokogiri'
require 'open-uri'
# puts 'What job would you like to search for?'
# query = gets.chomp

get '/' do
  base_url = 'https://sfbay.craigslist.org'
  page     = Nokogiri::HTML(open("https://sfbay.craigslist.org/search/#{params[:job]}")).css('ul')
  variable = ""
  page[9].css('.result-title').each_with_index do |x, index|
    link   = base_url + x['href']
    link   = "#{index + 1}. --> #{x.text} & link --> <a href='#{link}' target='_blank'>link</a><br>"
    variable += link
    # puts "#{index + 1}. --> #{x.text} & link --> #{link} <br>"
  end
  return variable
end
