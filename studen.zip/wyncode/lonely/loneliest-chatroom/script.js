$(function() {
      let messageBox = $('#new-message-body')
      let sendButton = $('#new-message-button')
      let conversation = $('#conversation')

      sendButton.click(function(){
        sendMessage()
      })
      function sendMessage(){
          newMessage(messageBox.val());
      }

      conversation.on('click', "li", function(){
        this.remove();
      })

      function newMessage(message){
        let internalMessage = '<li class="message"  ><a class="delete" href="#" >Delete</a><h3 class="author">Me</h3><p class="message-body">' + message + '</p><span class="timestamp">01:12</span></li>';
        conversation.append(internalMessage)
        messageBox.val('')
      }
      
      $(document).keypress(function(e) {
          if(e.which == 13) {
              sendMessage()
          }
      });
});
