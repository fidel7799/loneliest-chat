
In this life simulator, do what you want. Even generate winning lottery numbers!

- EG
